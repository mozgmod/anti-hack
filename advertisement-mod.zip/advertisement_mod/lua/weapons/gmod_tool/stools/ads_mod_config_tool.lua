TOOL.Category = "Venatuss' Addons"
TOOL.Name = "Advert Mod - Configuration Tool"

TOOL.ClientConVar[ "model_sign_adsmod" ] = "models/props/cs_assault/billboard.mdl"
TOOL.ClientConVar[ "price_sign_adsmod"] = "100"
TOOL.ClientConVar[ "usable_sign_adsmod"] = "true"
TOOL.ClientConVar[ "name_sign_adsmod"] = "Billboard"

TOOL.Information = {
	{ name = "left" },
	{ name = "right" },
	{ name = "reload" }
}

local function CanEditAdsMod( ply )
	
	if table.HasValue(AdsMod.Configuration.AdminGroups, ply:GetUserGroup() ) then

		return true
		
	else

		return false
	
	end
	
end

if ( CLIENT ) then
	language.Add( "tool.ads_mod_config_tool.name", "Advert Mod - Configuration Tool" )
	language.Add( "tool.ads_mod_config_tool.desc", "Use this tool to place billboards" )
	language.Add( "tool.ads_mod_config_tool.left", "Left Click to place a billboard" )
	language.Add( "tool.ads_mod_config_tool.right", "Right click on a billboard to config it" )
	language.Add( "tool.ads_mod_config_tool.reload", "Reload to remove a billboard" )
end

local function CreateSign( model, price, usable, pos, name, ply )
	
	if not AdsMod.Configuration.Signs[model] then return end
	
	local ent = ents.Create("adsmod_sign")
	ent:SetModel( model )
	ent:SetPos(pos)
	ent:Spawn()
	
	ent.Price = price
	
	ent.Usable = usable
	
	ent.Name = name
	
	ent.BillboardName = usable
	
	local data = AdsMod.Configuration.Signs[ent:GetModel()].DefaultAd
	
	ent.DefaultAd = data
	
	net.Start("AdsMod.Net.BroadcastConfig") 
		net.WriteTable( data )
		net.WriteInt( ent.Price, 32 )
		net.WriteEntity( ent )
	net.Broadcast()
	
	undo.Create( "Billboard" )
		undo.AddEntity( ent )
		undo.SetPlayer( ply )
	undo.Finish()
	
end

function TOOL:LeftClick(trace)
	
	if not SERVER then return end
	
	local ply = self:GetOwner()
	
	if not IsValid( ply ) or not CanEditAdsMod( ply ) then return end
	
	local model = self:GetClientInfo( "model_sign_adsmod" )
	local price = tonumber(self:GetClientInfo( "price_sign_adsmod" ))
	local use = tobool( self:GetClientInfo( "usable_sign_adsmod" ))
	local name = self:GetClientInfo( "name_sign_adsmod" )

	local pos = trace.HitPos
	
	CreateSign( model, price, use, pos, name, ply )
	
	return true
end

function TOOL:RightClick(trace)
	
	if not CLIENT then return end
	
	local ply = self:GetOwner()
	local ent = trace.Entity
	
	if not IsValid( ent ) or ent:GetClass() != "adsmod_sign" then return end
	
	if not IsValid( ply ) or not CanEditAdsMod( ply ) then return end
	
	ent:OpenGUIAdmin()
	
	return true
end

function TOOL:Reload(trace)
	
	if not SERVER then return end
	
	local ply = self:GetOwner()
	
	if not IsValid( ply ) or not CanEditAdsMod( ply ) then return end
	
	local ent = trace.Entity
	
	if not IsValid( ent ) then return end
	
	if ent:GetClass() == "adsmod_sign" then
		ent:Remove()
	end
	
	return true
end

function TOOL:Allowed() return CanEditAdsMod( self:GetOwner() ) end

function TOOL.BuildCPanel( CPanel )

	CPanel:AddControl( "Header", { Description = "Selection the model and the price that the player will have to pay to add an ad during one minute, then left click to place the billboard. Right click on it to save it." } )
	
	CPanel:AddControl( "textbox", { Label = "Name", Command = "ads_mod_config_tool_name_sign_adsmod" } )
	
	CPanel:AddControl( "PropSelect", { Label = "Select the model of the billboard", ConVar = "ads_mod_config_tool_model_sign_adsmod", Height = 0, Models = list.Get( "SignsModels" ) } )
	
	CPanel:AddControl( "checkbox", { Label = "Can be used by players ", Command = "ads_mod_config_tool_usable_sign_adsmod" } )
	
	CPanel:AddControl( "Slider", { Label = "Price per minutes ", Command = "ads_mod_config_tool_price_sign_adsmod", Min = 0, Max = 50000 } )

end



for k, v in pairs( AdsMod.Configuration.Signs ) do

	list.Set( "SignsModels", k, {} )
	
end