TOOL.Category = "Venatuss' Addons"
TOOL.Name = "Advert Mod - Information Tool"

TOOL.Information = {
	{ name = "left" },
	{ name = "right" },
}

local function AdsModCanGetInfos(ply)

	if table.HasValue(AdsMod.Configuration.AdminGroups, ply:GetUserGroup() ) or table.HasValue(AdsMod.Configuration.ModGroups, ply:GetUserGroup() ) then

		return true
		
	else

		return false
	
	end

end

local function CanEditAdsMod( ply )
	
	if table.HasValue(AdsMod.Configuration.AdminGroups, ply:GetUserGroup() ) then

		return true
		
	else

		return false
	
	end
	
end

if ( CLIENT ) then
	language.Add( "tool.ads_mod_info_tool.name", "Advert Mod - Information Tool" )
	language.Add( "tool.ads_mod_info_tool.desc", "Use this to get informations about a billboard" )
	language.Add( "tool.ads_mod_info_tool.left", "Left click to get in your console infos about a billboard" )
	language.Add( "tool.ads_mod_info_tool.right", "Right click on a billboard to remove the current ad on." )
end

function TOOL:LeftClick(trace)
	
	if not SERVER then return end
	
	local ply = self:GetOwner()
	
	if not IsValid( ply ) or not AdsModCanGetInfos( ply ) then return end
	
	local ent = trace.Entity
	
	if not IsValid( ent ) or ent:GetClass() != "adsmod_sign" then return end
	
	local name = ent.Name or "nil"
	
	ply:ChatPrint( "Billboard name : "..name )
	
	local ownerent = ent.AdOwner or NULL
	
	if IsValid( ownerent ) and ownerent:IsPlayer()  then
		local owner = ownerent:Name().." ( "..ownerent:SteamID().." )"
		ply:ChatPrint( "Current ad owner : "..owner)
	end
	
	if timer.Exists("TimerAds"..ent:EntIndex()) then
		ply:ChatPrint("Time left : "..math.Round(timer.TimeLeft("TimerAds"..ent:EntIndex())).." secs" )
	end
	
	return true
end

function TOOL:RightClick(trace)
	
	if not SERVER then return end
	
	local ply = self:GetOwner()
	local ent = trace.Entity
	
	if not IsValid( ent ) or ent:GetClass() != "adsmod_sign" then return end
	
	if not IsValid( ply ) or not AdsModCanGetInfos( ply ) then return end
		
	if timer.Exists( "TimerAds"..ent:EntIndex() ) then
		timer.Destroy( "TimerAds"..ent:EntIndex() )
	end
	
	AdsMod.SavedAds[ent] = {}
	
	ent.AdOwner = nil
	
	net.Start("AdsMod.Net.BroadcastData")
		net.WriteTable( AdsMod.SavedAds[ent] )
		net.WriteEntity( ent )
	net.Broadcast()
	
	return true
end

function TOOL:Reload(trace)
	return true
end

function TOOL:Allowed() return AdsModCanGetInfos( self:GetOwner() ) end

function TOOL.BuildCPanel( CPanel )

	CPanel:AddControl( "Header", { Description = "Selection the model and the price that the player will have to pay to add an ad during one minute, then left click to place the billboard. Right click on it to save it." } )
	
	CPanel:AddControl( "textbox", { Label = "Name", Command = "ads_mod_config_tool_name_sign_adsmod" } )
	
	CPanel:AddControl( "PropSelect", { Label = "Select the model of the billboard", ConVar = "ads_mod_config_tool_model_sign_adsmod", Height = 0, Models = list.Get( "SignsModels" ) } )
	
	CPanel:AddControl( "checkbox", { Label = "Can be used by players ", Command = "ads_mod_config_tool_usable_sign_adsmod" } )
	
	CPanel:AddControl( "Slider", { Label = "Price per minutes ", Command = "ads_mod_config_tool_price_sign_adsmod", Min = 0, Max = 50000 } )

end



for k, v in pairs( AdsMod.Configuration.Signs ) do

	list.Set( "SignsModels", k, {} )
	
end