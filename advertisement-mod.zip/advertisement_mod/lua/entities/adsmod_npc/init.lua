AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
	
	self:SetModel( AdsMod.Configuration.AdvertNPCModel )
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal()
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid(  SOLID_BBOX )
	self:CapabilitiesAdd( CAP_ANIMATEDFACE || CAP_TURN_HEAD )
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
	self.nextClick = CurTime() + 1
	self:SetMaxYawSpeed( 90 )
	
end

function ENT:AcceptInput( event, a, p )

	if( event == "Use" && p:IsPlayer() && self.nextClick < CurTime() )  then
	
		self.nextClick = CurTime() + 2
		
		local list = {}
		
		for k, ent in pairs( ents.FindByClass("adsmod_sign") ) do
			
			if IsValid( ent.AdOwner ) then continue end 
			if not ent.Usable then continue end
			
			list[ ent:EntIndex()] = {
				name = ent.Name or "Billboard",
				price = ent.Price or 100,
			}
			
		end
		
		net.Start("AdsMod.Net.NPCMenu")
			net.WriteEntity( self )
			net.WriteTable( list )
		net.Send( p )
		
	end
	
end