ENT.Type = "ai"
ENT.Base = "base_ai"
ENT.AutomaticFrameAdvance = true
ENT.Author = "Venatuss"
ENT.Spawnable = true
ENT.Category = "Advertisement Mod"
ENT.PrintName = "Advertisement NPC"