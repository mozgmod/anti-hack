ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Sign"
ENT.Category = "Ads Mod"
ENT.Author = "Venatuss"
ENT.Spawnable = false
