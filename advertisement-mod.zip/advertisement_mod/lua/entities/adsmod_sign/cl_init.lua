include("shared.lua")

function ENT:Draw()

    self:DrawModel()
	
end

function ENT:OnRemove()
	if IsValid( AdsMod.ListOfActualAds[self:EntIndex()] ) then
		AdsMod.ListOfActualAds[self:EntIndex()]:Remove()
	end
	
	AdsMod.ListOfActualAds[self:EntIndex()] = nil 
end

local string_format = string.format
local string_byte = string.byte
local function replacer( character )
	return string_format( "%%%.2X", string_byte( character, 1, 1 ) )
end
local string_gsub = string.gsub
function escapeUrl( url )
	-- http://www.faqs.org/rfcs/rfc1738.html
	return string_gsub( url, "[%z\x01-\x1F\x7F-\xFF<>\"']", replacer )
end

local matSwitchOn = Material( "materials/venatuss/lib/switch-on-icon.png" )
local matSwitchOff = Material( "materials/venatuss/lib/switch-off-icon.png" )
local venalib = include( "ads_mod/include/cl_library.lua" )

function ENT:CreateTextGUI( parent )
	
	local buttonText = vgui.Create( "DButton", parent )
	buttonText:SetText( "" )
	buttonText:SetPos( 25, 50 )
	buttonText:SetSize( 250, 30 )
	
	function buttonText:OnMousePressed( key )
	
		if key != MOUSE_FIRST then return end
		
		self.Move = true
		
		self.lastClickPosx, self.lastClickPosy = self:CursorPos()
		
	end
	
	function buttonText:OnMouseReleased( key )
	
		if key != MOUSE_FIRST then return end
		
		self.Move = false
		
		local ssizex, ssizey = self:GetSize()
		local posx, posy = self:GetPos()
		
		local x = math.Clamp(posx, 0, sizexpre-ssizex )
		local y = math.Clamp(posy, 0, sizeypre-ssizey-42 )
		
		self:SetPos(x,y)

	end
	
	function buttonText:Think()
		
		if not self.Move then return end
		
		local ssizex, ssizey = self:GetSize()
		
		local xwc, ywc = panel:CursorPos()
		
		local cposx = self.lastClickPosx 
		local cposy = self.lastClickPosy
		
		local x = math.Clamp(xwc-cposx, 0, sizexpre-ssizex )
		local y = math.Clamp(ywc-cposy, 0, sizeypre-ssizey-42 )
				
		self:SetPos(x,y)
		
	end
		
	buttonText.Text = AdsMod.Configuration.BaseText
	buttonText.Color = Color(255,255,255)
	buttonText.FontSize = 17
	buttonText.Outline = false
	
	function buttonText:Paint(w,h)
		draw.SimpleText( self:GetText(), "Bariol17", 0,0, self.Color )
	end
	
	local valu = table.Count(AddAdsPanel.Texts)+1
		
	AddAdsPanel.Texts[valu] = buttonText
		
end

function ENT:OpenPreviewGUI( Frame )
	
	local config = AdsMod.Configuration.Signs[self:GetModel()]
	local sizexp = config.sizex*600/config.sizex
	local sizeyp = config.sizey*600/config.sizex + 42

	
	local PreviewFrame, Preview = venalib.Frame( "Preview", sizexp, sizeyp, ScrW()-sizexp-10, 10,nil)
	
	-- BASE AD

	local panel = vgui.Create("DScrollPanel", PreviewFrame)
	panel:SetSize( PreviewFrame:GetSize() )
	panel:SetPos( 0, 0 )
	panel.Paint = function( pnl, w, h )
		draw.RoundedBox( 0, 0, 0, w,h, Color(0, 0, 0))
	end	
	
	local toadd = ""
	
	if AddAdsPanel.BackgroundAdjust then
		toadd = "background-size: 100% 100%;"
	end
	
	local dhtml = vgui.Create("HTML", panel )
	dhtml:SetPos( 0,0 )
	dhtml:SetSize( panel:GetSize() )
	dhtml:SetHTML( [[
	
    <html><head><style>body{
        background-attachment: fixed;
        background-image: url("]]..AddAdsPanel.Background..[[");
        background-repeat: repeat;
       ]]..toadd..[[
        overflow: hidden;
    }</style></head><body></body></html>
	
	]] 	)
	local i = 0
	local newTable = {}

	for k, v in pairs( AddAdsPanel.Texts ) do
		i = i + 1
		
		if not ispanel( v ) or not IsValid( v ) then return end
		
		local color = v.Color or Color(255,255,255)
		local text = v.Text or ""
		local FontSizer = v.FontSize or 17
		local FontSize = math.Round(FontSizer)
		local outline = v.Outline or false
		
		surface.SetFont( "Bariol"..FontSize )
		surface.SetTextColor( color )
		surface.SetTextPos( 0, 0 )
		local sizex, sizey = surface.GetTextSize( text )
		
		local buttonText = vgui.Create( "DButton", dhtml )
		buttonText:SetText( "" )
		buttonText:SetPos( v:GetPos() )
		buttonText:SetSize( sizex, sizey )
		
		function buttonText:OnMousePressed( key )
		
			if key != MOUSE_FIRST then return end
			
			self.Move = true
			
			self.lastClickPosx, self.lastClickPosy = self:CursorPos()
			
		end
		
		function buttonText:OnMouseReleased( key )
		
			if key != MOUSE_FIRST then return end
			
			self.Move = false
			
			local ssizex, ssizey = self:GetSize()
			local posx, posy = self:GetPos()
			
			local x = math.Clamp(posx, 0, sizexp-ssizex  )
			local y = math.Clamp(posy, 0, sizeyp-ssizey-42 )
			
			self:SetPos(x,y)

		end
		
		function buttonText:Think()
			
			if not self.Move then return end
			
			local ssizex, ssizey = self:GetSize()
			
			local xwc, ywc = panel:CursorPos()
			
			local cposx = self.lastClickPosx or 0
			local cposy = self.lastClickPosy or 0
			
			local x = math.Clamp(xwc-cposx, 0, sizexp-ssizex )
			local y = math.Clamp(ywc-cposy, 0, sizeyp-ssizey-42 )
					
			self:SetPos(x,y)
			
		end
		
		function buttonText:Paint(w,h)
			if outline then
				local outlinewidth = 2

				local steps = ( outlinewidth * 2 ) / 3
				if ( steps < 1 ) then steps = 1 end

				for _x = -outlinewidth, outlinewidth, steps do
					for _y = -outlinewidth, outlinewidth, steps do
						draw.SimpleText( text, "Bariol"..FontSize, 0 + _x, 0 + _y, Color(0,0,0))
					end
				end
			end
						
			surface.SetFont( "Bariol"..FontSize )
			surface.SetTextColor( color )
			surface.SetTextPos( 0, 0 )
			surface.DrawText( text )
		end
				
		buttonText.Text = text
		buttonText.Color = color
		buttonText.FontSize = FontSize
		buttonText.Outline = outline
		
		AddAdsPanel.Texts[k]:Remove()
		newTable[i] = buttonText
	end
	
	AddAdsPanel.Texts = newTable
	
	---------------------------------------
	local i = 0
	local newTable2 = {}

	for k, v in pairs( AddAdsPanel.Images ) do
		i = i + 1
		
		if not ispanel( v ) or not IsValid( v ) then return end
		
		local dhtml2 = vgui.Create("HTML", dhtml )
		dhtml2:SetPos( v:GetPos() )
		dhtml2:SetSize( v.SizeX, v.SizeY )

		dhtml2.HTMLLink = v.HTMLLink
		dhtml2.SizeX = v.SizeX
		dhtml2.SizeY = v.SizeY	
		
		dhtml2:SetHTML( [[
		
		<html><head><style>body{
			background-attachment: fixed;
			background-image: url("]]..dhtml2.HTMLLink..[[");
			background-repeat: repeat;
			background-size: 100% 100%;
			overflow: hidden;
		}</style></head><body></body></html>
		
		]] 	)
		
		local buttonImg = vgui.Create( "DButton", dhtml )
		buttonImg:SetText( "" )
		buttonImg:SetPos( dhtml2:GetPos() )
		buttonImg:SetSize( dhtml2:GetSize() )
		
		function buttonImg:OnMousePressed( key )
		
			if key != MOUSE_FIRST then return end
			
			self.Move = true
			
			self.lastClickPosx, self.lastClickPosy = self:CursorPos()
			
		end
		
		function buttonImg:OnMouseReleased( key )
		
			if key != MOUSE_FIRST then return end
			
			self.Move = false
			
			local ssizex, ssizey = self:GetSize()
			local posx, posy = self:GetPos()
			local sizexpre, sizeypre = dhtml:GetSize()
			
			local x = math.Clamp(posx, 0, sizexpre-ssizex )
			local y = math.Clamp(posy, 0, sizeypre-ssizey )
			
			self:SetPos(x,y)
			dhtml2:SetPos( x, y )

		end
		
		function buttonImg:Think()
			
			if not self.Move then return end
			
			local ssizex, ssizey = self:GetSize()
			
			local xwc, ywc = dhtml:CursorPos()
			local sizexpre, sizeypre = dhtml:GetSize()
			
			local cposx = self.lastClickPosx or 0
			local cposy = self.lastClickPosy or 0
			
			local x = math.Clamp(xwc-cposx, 0, sizexpre-ssizex )
			local y = math.Clamp(ywc-cposy, 0, sizeypre-ssizey )
			
			self:SetPos(x,y)
			dhtml2:SetPos( x, y )
			
		end
		
		function buttonImg:Paint()
		end
		
		buttonImg.pHTML = dhtml2
		dhtml2.button = buttonImg
		
		
		AddAdsPanel.Images[k]:Remove()
		newTable2[i] = dhtml2
	end
	
	AddAdsPanel.Images = newTable2
	----------------------------------------
	--
	if not Frame then return Preview, PreviewFrame end
	
	Preview.Linked = Frame
	Frame.Linked = Preview
	Frame.HTML = dhtml
	Preview.HTML = dhtml

	return Preview, PreviewFrame

end

local lang = AdsMod.Configuration.Lang

function ENT:OpenBackgroundGUI( MainFrame, PreviewGUI )
	
	local sizex = 600
	local sizey = 400
	
	local panelM = venalib.Panel( sizex-160, sizey-40, 160, 0, MainFrame )
	local panelM1Title = venalib.Label( AdsMod.Configuration.Sentences["Background settings"][lang], 20, sizex-160, 20, 20, 10 , Color(255,255,255), panelM )
	panelM1Title:SetWrap(false)
	
	local panelM2Title = venalib.Label( AdsMod.Configuration.Sentences["Link"][lang], 18, sizex-160, 20, 20, 45 , Color(255,255,255), panelM )
	panelM2Title:SetWrap(false)
	
	local text = vgui.Create( "DTextEntry", panelM )
	text:SetPos( 20, 70 )
	text:SetSize( sizex-40-160, 25 )
	text:SetText( AddAdsPanel.Background )
	
	local panelM3Title = venalib.Label( AdsMod.Configuration.Sentences["Auto-adjust size"][lang], 18, sizex-160, 20, 20, 115 , Color(255,255,255), panelM )
	panelM3Title:SetWrap(false)
	
	local DermaCheckbox = vgui.Create( "DCheckBox", panelM )
	DermaCheckbox:SetPos( 20, 115+20+5 )
	DermaCheckbox:SetSize( 50,50 )
	if AddAdsPanel.BackgroundAdjust then
		DermaCheckbox:SetValue( 1 )
	else
		DermaCheckbox:SetValue( 0 )
	end
	
	DermaCheckbox.OnChange = function( panel, val )
		if (val) then
			 AddAdsPanel.BackgroundAdjust = true
		else
			 AddAdsPanel.BackgroundAdjust = false
		end
	end
	
	DermaCheckbox.Paint = function( pnl, w, h )
		
		if DermaCheckbox:GetChecked() then
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( matSwitchOn )
			surface.DrawTexturedRect( 0, 0, w, h )
		else
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( matSwitchOff )
			surface.DrawTexturedRect( 0, 0, w, h )
		end
		
	end
	
	local button = venalib.Button( AdsMod.Configuration.Sentences["Update"][lang], 100, 40, sizex-160-100-10, sizey-80-10, function() 
		
	
		
		local text_s = text:GetText()
		
		for key, val in pairs( AdsMod.Configuration.ForbiddenStrings ) do
			
			local text_v = string.find( text_s, val )
			
			if text_v then return end
		
		end
		
		local linked = PreviewGUI.Linked 
		
		if PreviewGUI then PreviewGUI:Remove() end 
		
		AddAdsPanel.Background = escapeUrl(text_s)

		PreviewGUI = self:OpenPreviewGUI(linked) 
		
	end,panelM )
	
end

function ENT:OpenTextGUI( MainFrame, Frame )
		
	local sizex = 600
	local sizey = 400
	
	local panelM = venalib.Panel( sizex-160, sizey-40, 160, 0, MainFrame )
	local panelM1Title = venalib.Label( AdsMod.Configuration.Sentences["Texts settings"][lang], 20, sizex-160, 20, 20, 10 , Color(255,255,255), panelM )
	panelM1Title:SetWrap(false)
	
	local lastpos = 0
	
	for k, v in pairs(  AddAdsPanel.Texts ) do
		
		if not IsValid( v ) then continue end
		
		local txt = v.Text or ""
		local fontsize = v.FontSize or 17
		local color = v.Color or Color(255,255,255)
		local outline = v.Outline or false
		
		lastpos = k
		
		local panelM1 = venalib.Panel( sizex-160, ( 70 + 70 * 2 + 190 + 40 + 20), 0, 30+( 70 + 70 * 2 + 190 +40 + 20 ) * (k-1) , panelM )
		
		local panelM2Title = venalib.Label( AdsMod.Configuration.Sentences["Text"][lang].." "..k.." :", 18, sizex-160, 20, 20, 45 , Color(255,255,255), panelM1 )
		panelM2Title:SetWrap(false)
		
		local text = vgui.Create( "DTextEntry", panelM1 )
		text:SetPos( 20, 70 )
		text:SetSize( sizex-40-160, 25 )
		text:SetText( txt )
		
		text.OnTextChanged = function()
			
			local text_s =text:GetText()
			
			for key, val in pairs( AdsMod.Configuration.ForbiddenStrings ) do
			
				local text_v = string.find( text_s, val )
				
				if text_v then return end
			
			end
			
			AddAdsPanel.Texts[k].Text =  text_s
		end
		
		local panelM3Title = venalib.Label( AdsMod.Configuration.Sentences["Text"][lang].." "..k.." "..AdsMod.Configuration.Sentences["size"][lang].." :", 18, sizex-160, 20, 20, 45 + 70 , Color(255,255,255), panelM1 )
		panelM3Title:SetWrap(false)
		
		local DermaNumSlider = vgui.Create( "DNumSlider", panelM1 )
		DermaNumSlider:SetPos(-sizex/2+80, 70 + 70 )
		DermaNumSlider:SetSize( sizex-40, 25  )
		DermaNumSlider:SetMin( 0 )
		DermaNumSlider:SetMax( 100 )
		DermaNumSlider:SetDecimals( 0 )
		DermaNumSlider:SetValue( fontsize )
		
		DermaNumSlider.OnValueChanged = function( val )
		
			AddAdsPanel.Texts[k].FontSize =  DermaNumSlider:GetValue()
			
		end
		
		local panelM3Title = venalib.Label( AdsMod.Configuration.Sentences["Text"][lang].." "..k.." "..AdsMod.Configuration.Sentences["outlined"][lang].." :", 18, sizex-160, 20, 20, 45 + 70 *2 , Color(255,255,255), panelM1 )
		panelM3Title:SetWrap(false)	
		
		local DermaCheckbox = vgui.Create( "DCheckBox", panelM1 )
		DermaCheckbox:SetPos( 20, 70 + 70 * 2)
		DermaCheckbox:SetSize( 50,50 )
		if outline then
			AddAdsPanel.Texts[k].Outline = true
			DermaCheckbox:SetValue( 1 )
		else
			AddAdsPanel.Texts[k].Outline = false
			DermaCheckbox:SetValue( 0 )
		end
				
		DermaCheckbox.OnChange = function( panel, val )
			AddAdsPanel.Texts[k].Outline = DermaCheckbox:GetChecked()
		end
		
		DermaCheckbox.Paint = function( pnl, w, h )
			
			if DermaCheckbox:GetChecked() then
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.SetMaterial( matSwitchOn )
				surface.DrawTexturedRect( 0, 0, w, h )
			else
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.SetMaterial( matSwitchOff )
				surface.DrawTexturedRect( 0, 0, w, h )
			end
			
		end
		
		
		local panelM4Title = venalib.Label( AdsMod.Configuration.Sentences["Text"][lang].." "..k.." "..AdsMod.Configuration.Sentences["color"][lang].." :", 18, sizex-160, 20, 20, 50+20+45 + 70 *2 , Color(255,255,255), panelM1 )
		panelM4Title:SetWrap(false)
		
		local Mixer = vgui.Create( "DColorMixer", panelM1 )
		Mixer:SetPos(20, 50+20+70 + 70 * 2)
		Mixer:SetPalette( true )
		Mixer:SetAlphaBar( true )
		Mixer:SetWangs( true )
		Mixer:SetColor( color )
		
		Mixer.ValueChanged = function()
			AddAdsPanel.Texts[k].Color = Mixer:GetColor()
		end
		
		local button2 = venalib.Button( AdsMod.Configuration.Sentences["Remove"][lang].." "..string.lower(AdsMod.Configuration.Sentences["Text"][lang]), 120, 40, sizex-160-100-50, 70 + 70 * 2 + 190 - 45, function() 
			AddAdsPanel.Texts[k] = nil
			
			if ispanel(Frame.Linked) then 
			
				Frame.Linked:Remove() 
				local nframe = self:OpenPreviewGUI( Frame ) 
				Frame.Linked = nframe
				
			end
			self:OpenTextGUI( MainFrame, Frame )
			
		end,panelM1 )

		local button1 = venalib.Button( AdsMod.Configuration.Sentences["Update"][lang].." "..string.lower(AdsMod.Configuration.Sentences["Text"][lang]), 120, 40, sizex-160-100-50, 70 + 70 * 2 + 190, function() 
			
			local text_s = text:GetText()
			
			for key, val in pairs( AdsMod.Configuration.ForbiddenStrings ) do
			
				local text_v = string.find( text_s, val )
				
				if text_v then return end
			
			end
			
			AddAdsPanel.Texts[k].Color = Mixer:GetColor()
			AddAdsPanel.Texts[k].Text =  text:GetText()
			AddAdsPanel.Texts[k].FontSize =  DermaNumSlider:GetValue()
			AddAdsPanel.Texts[k].Outline =  DermaCheckbox:GetChecked()
				
			if ispanel(Frame.Linked) then 
			
				Frame.Linked:Remove() 
				local nframe = self:OpenPreviewGUI( Frame ) 
				Frame.Linked = nframe
				
			end
		end,panelM1 )
	
	end
	
	local buttonAdd = venalib.Button( AdsMod.Configuration.Sentences["Add"][lang], 150, 40, (sizex-160)/2-150/2, lastpos * ( 70 + 70 * 2 + 190 +40 + 20 ) + 40 , function() 
		
		self:CreateTextGUI( MainFrame.HTML )
		self:OpenTextGUI( MainFrame, Frame )
				
		if ispanel(Frame.Linked) then 
		
			Frame.Linked:Remove() 
			local nframe = self:OpenPreviewGUI( Frame ) 
			Frame.Linked = nframe
			
		end

	end,panelM )
	
	local buttonUpdateAll = venalib.Button( AdsMod.Configuration.Sentences["Update all"][lang], 150, 40, (sizex-160)/2-150/2, lastpos * ( 70 + 70 * 2 + 190 +40 + 20 ) + 40 + 50 , function() 
			
		if ispanel(Frame.Linked) then 
			
			Frame.Linked:Remove() 
			local nframe = self:OpenPreviewGUI( Frame ) 
			Frame.Linked = nframe
				
		end
		
	end,panelM )
	
end

function ENT:CreateImageGUI( parent )
		
	if not IsValid( parent ) then return end
	
	local dhtml = vgui.Create("HTML", parent )
	dhtml:SetPos( 0,0 )
	dhtml:SetSize( 50,50 )

	dhtml.HTMLLink = AdsMod.Configuration.BaseImg
	dhtml.SizeX = 50
	dhtml.SizeY = 50

	dhtml:SetHTML( [[
	
    <html><head><style>body{
        background-attachment: fixed;
        background-image: url("]]..dhtml.HTMLLink..[[");
        background-repeat: repeat;
		background-size: 100% 100%;
        overflow: hidden;
    }</style></head><body></body></html>
	
	]] 	)
	
	local buttonImg = vgui.Create( "DButton", parent )
	buttonImg:SetText( "" )
	buttonImg:SetPos( dhtml:GetPos() )
	buttonImg:SetSize( dhtml:GetSize() )
	
	function buttonImg:OnMousePressed( key )
	
		if key != MOUSE_FIRST then return end
		
		self.Move = true
		
	end
	
	function buttonImg:OnMouseReleased( key )
	
		if key != MOUSE_FIRST then return end
		
		self.Move = false
		
		local ssizex, ssizey = self:GetSize()
		local posx, posy = self:GetPos()
		local sizexpre, sizeypre = parent:GetSize()
		
		local x = math.Clamp(posx, 0, sizexpre-ssizex )
		local y = math.Clamp(posy, 0, sizeypre-ssizey )
		
		self:SetPos(x,y)
		dhtml:SetPos( x, y )

	end
	
	function buttonImg:Think()
		
		if not self.Move then return end
		
		local ssizex, ssizey = self:GetSize()
		
		local xwc, ywc = parent:CursorPos()
		local sizexpre, sizeypre = parent:GetSize()
		
		local x = math.Clamp(xwc, 0, sizexpre-ssizex )
		local y = math.Clamp(ywc, 0, sizeypre-ssizey )
		
		self:SetPos(x,y)
		dhtml:SetPos( x, y )
		
	end
	
	function buttonImg:Paint()
	end
	
	buttonImg.pHTML = dhtml
	dhtml.button = buttonImg
	
	local valu = table.Count(AddAdsPanel.Images)+1
		
	AddAdsPanel.Images[valu] = dhtml
		
end

function ENT:OpenImagesGUI( MainFrame, Frame )
	
	local sizex = 600
	local sizey = 400
	
	local panelM = venalib.Panel( sizex-160, sizey-40, 160, 0, MainFrame )
	
	local lastpos = 0
	for k, v in pairs(  AddAdsPanel.Images ) do
				
		if not IsValid(  AddAdsPanel.Images[k] ) then continue end
		
		local txt =  AddAdsPanel.Images[k].HTMLLink or ""
		
		lastpos = k
		
		local panelM1 = venalib.Panel( sizex-160, 70 + 50*2 + 50 + 50, 0, ( 70 + 50*2 + 50 + 50 ) * (k-1) , panelM )
		
		local panelM2Title = venalib.Label( AdsMod.Configuration.Sentences["Image"][lang].." "..k.." "..string.lower(AdsMod.Configuration.Sentences["Link"][lang]).." :", 18, sizex-160, 20, 20, 45 , Color(255,255,255), panelM1 )
		panelM2Title:SetWrap(false)
		
		local text = vgui.Create( "DTextEntry", panelM1 )
		text:SetPos( 20, 70 )
		text:SetSize( sizex-40-160, 25 )
		text:SetText( txt )
		
		text.OnTextChanged = function()
			
			if not IsValid(  AddAdsPanel.Images[k] ) then return end
			
			local text_s =text:GetText()
			
			for key, val in pairs( AdsMod.Configuration.ForbiddenStrings ) do
			
				local text_v = string.find( text_s, val )
				
				if text_v then return end
			
			end
			
			 AddAdsPanel.Images[k].HTMLLink = escapeUrl(text:GetText())
		end
		
		local panelM3Title = venalib.Label(AdsMod.Configuration.Sentences["Image"][lang].." "..k.." "..AdsMod.Configuration.Sentences["size"][lang].." :", 18, sizex-160, 20, 20, 45 + 70 , Color(255,255,255), panelM1 )
		panelM3Title:SetWrap(false)
		
		local sizext =  AddAdsPanel.Images[k].SizeX
		local sizeyt =  AddAdsPanel.Images[k].SizeY
		
		local text2 = vgui.Create( "DTextEntry", panelM1 )
		text2:SetPos( 20, 70+70 )
		text2:SetSize( (sizex-40-160)/2-5, 25 )
		text2:SetNumeric( true )
		text2:SetText( sizext )
		
		text2.OnTextChanged = function()
			
			if not IsValid(  AddAdsPanel.Images[k] ) then return end
			
			local x, y = AddAdsPanel.Images[k]:GetPos()
			
		 AddAdsPanel.Images[k].SizeX = text2:GetText()
		end
		
		local text3 = vgui.Create( "DTextEntry", panelM1 )
		text3:SetPos( (sizex-40-160)/2+5+20, 70+70 )
		text3:SetSize( (sizex-40-160)/2-5, 25 )
		text3:SetNumeric( true )
		text3:SetText( sizeyt )
		
		text3.OnTextChanged = function()
			
			if not IsValid( AddAdsPanel.Images[k] ) then return end
			
			local x, y = AddAdsPanel.Images[k]:GetPos()
			
			AddAdsPanel.Images[k].SizeY = text3:GetText()
		end
		
		local button2 = venalib.Button( AdsMod.Configuration.Sentences["Remove"][lang].." "..string.lower(AdsMod.Configuration.Sentences["Image"][lang]), 120, 40, sizex-160-100-50, 70 + 50 + 50 , function() 
			AddAdsPanel.Images[k] = nil
			
			if ispanel(Frame.Linked) then 
			
				Frame.Linked:Remove() 
				local nframe = self:OpenPreviewGUI( Frame ) 
				Frame.Linked = nframe
						
			end
			
			self:OpenImagesGUI( MainFrame, Frame )
			
		end,panelM1 )

		local button1 = venalib.Button( AdsMod.Configuration.Sentences["Update"][lang].." "..string.lower(AdsMod.Configuration.Sentences["Image"][lang]), 120, 40, sizex-160-100-50, 70 + 50*2 + 50, function() 

			if IsValid( AddAdsPanel.Images[k] ) then
				
				local text_s =text:GetText()
			
				for key, val in pairs( AdsMod.Configuration.ForbiddenStrings ) do
				
					local text_v = string.find( text_s, val )
					
					if text_v then return end
				
				end
			
				AddAdsPanel.Images[k].HTMLLink = escapeUrl(text:GetText())
				AddAdsPanel.Images[k].SizeX = text2:GetText()
				AddAdsPanel.Images[k].SizeY = text3:GetText()
				if ispanel(Frame.Linked) then 
			
					Frame.Linked:Remove() 
					local nframe = self:OpenPreviewGUI( Frame ) 
					Frame.Linked = nframe
					
				end
				
			end
			
		end,panelM1 )
	
	end
	
	local buttonUpdateAll = venalib.Button( AdsMod.Configuration.Sentences["Update all"][lang], 150, 40, (sizex-160)/2-150/2, lastpos * (70 + 50*2 + 50 + 50) + 50 + 30 - math.Clamp( lastpos * 30, 0, 30 ), function() 
						
		if ispanel(Frame.Linked) then 
			
			Frame.Linked:Remove() 
			local nframe = self:OpenPreviewGUI( Frame ) 
			Frame.Linked = nframe
					
		end
		
	end,panelM )
	
	local buttonAdd = venalib.Button( AdsMod.Configuration.Sentences["Add"][lang], 150, 40, (sizex-160)/2-150/2, lastpos * (70 + 50*2 + 50 + 50)  + 30 - math.Clamp( lastpos * 30, 0, 30 ), function() 
				
		self:CreateImageGUI( Frame.HTML )
		self:OpenImagesGUI( MainFrame, Frame )
				
		if ispanel(Frame.Linked) then 
			
			Frame.Linked:Remove() 
			local nframe = self:OpenPreviewGUI( Frame ) 
			Frame.Linked = nframe
					
		end

	end,panelM )
	
	local panelM1Title = venalib.Label( AdsMod.Configuration.Sentences["Images settings"][lang], 20, sizex-160, 20, 20, 10 , Color(255,255,255), panelM )
	panelM1Title:SetWrap(false)
	
end

function ENT:OpenFinishGUI( MainFrame, Frame )
	
	local sizex = 600
	local sizey = 400
	
	local panelM = venalib.Panel( sizex-160, sizey-40, 160, 0, MainFrame )
	
	local panelM2Title = venalib.Label( AdsMod.Configuration.Sentences["How long do you want to add your advertising? ( in minutes )"][lang], 16, sizex-160, 20, 20, 45 , Color(255,255,255), panelM )
	panelM2Title:SetWrap(false)
	
	local panelM1Title = venalib.Label( AdsMod.Configuration.Sentences["Price"][lang].." : ", 15, sizex-160, 20, 20, 130 , Color(255,255,255), panelM )
	panelM1Title:SetWrap(false)
	
	local DermaNumSlider = vgui.Create( "DNumSlider", panelM )
		DermaNumSlider:SetPos(-sizex/2+80, 90  )
		DermaNumSlider:SetSize( sizex-40, 25  )
		DermaNumSlider:SetMin( 1 )
		DermaNumSlider:SetMax( AdsMod.Configuration.TimeMax )
		DermaNumSlider:SetDecimals( 0 )
		DermaNumSlider:SetValue( fontsize )
		
		DermaNumSlider.OnValueChanged = function( val )
			local pricetxt = AdsMod.Configuration.Sentences["Price"][lang] or "Price"
			local entindex = self:EntIndex() or 1
			local entpriceunit = AdsMod.AdsPrices[entindex] or 0
			local dermaval = math.Round(DermaNumSlider:GetValue()) or 1
			local price = math.Round(entpriceunit * dermaval )
			panelM1Title:SetText( pricetxt.." : "..price.."$" )
		end
	
	local adsprices = AdsMod.AdsPrices[self:EntIndex()] or 0
	local dermaval = DermaNumSlider:GetValue() or 0
	
	panelM1Title:SetText( AdsMod.Configuration.Sentences["Price"][lang].." : "..math.Round(adsprices * math.Round(dermaval)).."$" )
	
	local buttonPay = venalib.Button( AdsMod.Configuration.Sentences["Buy"][lang], 150, 40, (sizex-160)/2-150/2, 170, function() 

	local data = {}
	data.Background = AddAdsPanel.Background
	data.BackgroundAdjust = AddAdsPanel.BackgroundAdjust
	data.EntityMdl = self:GetModel()
	data.Time = math.Round(DermaNumSlider:GetValue())
	
	data.Texts = {}
	
	for k, v in pairs( AddAdsPanel.Texts ) do
		
		if not IsValid( v ) then continue end
		
		data.Texts[k] = {}
		
		local posx, posy = v:GetPos()
		
		data.Texts[k].posx = posx
		data.Texts[k].posy = posy
		data.Texts[k].Color = v.Color
		data.Texts[k].Text =  v.Text
		data.Texts[k].FontSize = v.FontSize
		data.Texts[k].Outline = v.Outline
		
	end
	
	data.Images = {}
	
	for k, v in pairs( AddAdsPanel.Images ) do
		
		if not IsValid( v ) then continue end

		data.Images[k] = {}
		
		local posx, posy = v:GetPos()
		local sizex, sizey = v:GetSize()
		
		data.Images[k].posx = posx
		data.Images[k].posy = posy
		data.Images[k].sizex = sizex
		data.Images[k].sizey = sizey
		data.Images[k].HTMLLink = escapeUrl(v.HTMLLink)
		
		
	end
	
	net.Start("AdsMod.Net.AdDataToServer")
		net.WriteTable( data )
		net.WriteEntity( self )
	net.SendToServer()
	
	AdsMod.infosAdsView = false
	if Frame and IsValid( Frame ) then Frame:Remove() end
	if Frame.Linked and IsValid( Frame.Linked ) then
		Frame.Linked:Remove()
	end
	
	end,
	panelM)
	
end


function ENT:OpenGUI()
	
	AddAdsPanel.Background = AdsMod.Configuration.BaseBackground
	AddAdsPanel.BackgroundAdjust = true
	AddAdsPanel.Texts = {}
	AddAdsPanel.Images = {}
	
	local sizex = 600
	local sizey = 400
	local MainFrame, Frame = venalib.Frame( AdsMod.Configuration.Sentences["Advertising"][lang],sizex,sizey,10,10 )
	
	AdsMod.infosAdsView = {
		starttime = CurTime(),
		ent = self,
	}
	
	MainFrame.Paint = function( pnl, w, h )
		draw.RoundedBox( 0, 0, 0, w,h, Color(36, 36, 44))
	end
	
	local Preview, PFrame = self:OpenPreviewGUI( Frame )

	local button1 = venalib.Button( AdsMod.Configuration.Sentences["Background"][lang], 160, 40, 0, 0, function() if IsValid(panelM) then panelM:Remove() end panelM = self:OpenBackgroundGUI( MainFrame, Preview ) end,MainFrame )
	local button2 = venalib.Button( AdsMod.Configuration.Sentences["Add/Edit Text"][lang], 160, 40, 0, 40, function() if IsValid(panelM) then panelM:Remove() end panelM = self:OpenTextGUI( MainFrame, Frame ) end,MainFrame )
	local button3 = venalib.Button( AdsMod.Configuration.Sentences["Add/Edit image"][lang], 160, 40, 0, 80, function() if IsValid(panelM) then panelM:Remove() end panelM = self:OpenImagesGUI( MainFrame, Frame ) end,MainFrame )
	local button3 = venalib.Button( AdsMod.Configuration.Sentences["Finish"][lang], 160, 40, 0, 120, function() if IsValid(panelM) then panelM:Remove() end panelM = self:OpenFinishGUI( MainFrame, Frame ) end,MainFrame )
	
	local panelM = self:OpenBackgroundGUI(MainFrame, Preview)	
	
end


-- ADMIN things
function ENT:OpenGUIAdmin()
	
	AddAdsPanel.Background = AdsMod.Configuration.BaseBackground
	AddAdsPanel.BackgroundAdjust = true
	AddAdsPanel.Texts = {}
	AddAdsPanel.Images = {}
	
	local sizex = 600
	local sizey = 400
	local MainFrame, Frame = venalib.Frame( AdsMod.Configuration.Sentences["Advertising"][lang].." - Admin Config - default ad",sizex,sizey,10,10 )
	
	AdsMod.infosAdsView = {
		starttime = CurTime(),
		ent = self,
	}
	
	MainFrame.Paint = function( pnl, w, h )
		draw.RoundedBox( 0, 0, 0, w,h, Color(36, 36, 44))
	end
	
	local Preview, PFrame = self:OpenPreviewGUI( Frame )

	local button1 = venalib.Button( "Background", 160, 40, 0, 0, function() if IsValid(panelM) then panelM:Remove() end panelM = self:OpenBackgroundGUI( MainFrame, Preview ) end,MainFrame )
	local button2 = venalib.Button( "Add/Edit Text", 160, 40, 0, 40, function() if IsValid(panelM) then panelM:Remove() end panelM = self:OpenTextGUI( MainFrame, Frame ) end,MainFrame )
	local button3 = venalib.Button( "Add/Edit image", 160, 40, 0, 80, function() if IsValid(panelM) then panelM:Remove() end panelM = self:OpenImagesGUI( MainFrame, Frame ) end,MainFrame )
	local button3 = venalib.Button( "Set as default", 160, 40, 0, 120, function()

	if IsValid(panelM) then panelM:Remove()	end 
	
	local data = {}
	data.Background = escapeUrl(AddAdsPanel.Background)
	data.BackgroundAdjust = AddAdsPanel.BackgroundAdjust
	data.EntityMdl = self:GetModel()
	
	data.Texts = {}
	
	for k, v in pairs( AddAdsPanel.Texts ) do
		
		if not IsValid( v ) then continue end
		
		data.Texts[k] = {}
		
		local posx, posy = v:GetPos()
		
		data.Texts[k].posx = posx
		data.Texts[k].posy = posy
		data.Texts[k].Color = v.Color
		data.Texts[k].Text =  v.Text
		data.Texts[k].FontSize = v.FontSize
		data.Texts[k].Outline = v.Outline
		
	end
	
	data.Images = {}
	
	for k, v in pairs( AddAdsPanel.Images ) do
		
		if not IsValid( v ) then continue end

		data.Images[k] = {}
		
		local posx, posy = v:GetPos()
		local sizex, sizey = v:GetSize()
		
		data.Images[k].posx = posx
		data.Images[k].posy = posy
		data.Images[k].sizex = sizex
		data.Images[k].sizey = sizey
		data.Images[k].HTMLLink = escapeUrl(v.HTMLLink)
		
		
	end
	
	net.Start("AdsMod.Net.AdDefaultConfig")
		net.WriteTable( data )
		net.WriteEntity( self )
	net.SendToServer()
	
	end,MainFrame )
	
	local panelM = self:OpenBackgroundGUI(MainFrame, Preview)	
	
end

