AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()

	-- self:SetModel("models/props/cs_assault/billboard.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	-- self:DropToFloor()
	local phys = self:GetPhysicsObject()
	
	if phys:IsValid() then
	
		phys:Wake()
		
	end
	
	local phys = self:GetPhysicsObject()
	
	if phys:IsValid() then
	
		phys:Wake()
		
	end
	
	timer.Simple( 0.1, function()
		if not IsValid( self ) then return end
		local data = AdsMod.Configuration.Signs[self:GetModel()].DefaultAd
		
		self.DefaultAd = data
		self.Price = self.Price or 100
		self.Usable = true
		
		local price = self.Price or 100
		
		net.Start("AdsMod.Net.BroadcastConfig") 
			net.WriteTable( data )
			net.WriteInt( price, 32 )
			net.WriteEntity( self )
		net.Broadcast()
	end)
	
end

function ENT:Use( a, c )
		
	if AdsMod.Configuration.CanEditBillboardsOnlyOnNPC then return end
	if not self.Usable then return end
	
	if self.AdOwner and IsValid( self.AdOwner ) then 
		DarkRP.notify(c, 1, 10, AdsMod.Configuration.Sentences["This billboard is already used by another player."][AdsMod.Configuration.Lang] ) 
		return 
	end
	
	net.Start("AdsMod.Net.OpenGUI")
		net.WriteEntity( self )
	net.Send( c )
	
end