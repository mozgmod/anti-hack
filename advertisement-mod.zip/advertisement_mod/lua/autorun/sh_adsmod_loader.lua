MsgC(Color(255,0,0), "[ADS Mod]", Color(255,255,255), "Loading files...")

-- Config
AdsMod = AdsMod or {}
AdsMod.Version = "1.1.1"
AddAdsPanel = {}
AddAdsPanel.Background = "https://steamuserimages-a.akamaihd.net/ugc/445081408343155496/A8F6740E9948BA678A620BE75D41FF14B31CF86A/"
AddAdsPanel.BackgroundAdjust = true
AddAdsPanel.Texts = {}
AddAdsPanel.Images = {}

AdsMod.infosAdsView = false 

AdsMod.SavedAds = {}

AdsMod.Configuration = {}

AdsMod.Configuration.Signs = {}

AdsMod.Configuration.Signs["models/props/cs_assault/billboard.mdl"] = {
	viewpos = Vector(100.322128,50.424347,100.465521),
	viewang = Angle(20.334,-160.269,0.341),
	sizex = 222,
	sizey = 115,
	
	FunctRender = function( sizex, sizey, sizexp, sizeyp, angle, position, ent )
		
		if not CLIENT then return end
		
		angle:RotateAroundAxis(angle:Forward(), 90);
		angle:RotateAroundAxis(angle:Right(),-90);
		angle:RotateAroundAxis(angle:Up(), 0);
		
		position = position + angle:Forward() * -111 + angle:Up() * 1 + angle:Right() * -57
		
		cam.Start3D2D(position, angle, sizex/600)
			
			draw.RoundedBox( 0, -0, -0, sizexp, sizeyp, Color(0,0,0) )
			
			if AdsMod.ListOfActualAds and IsValid( AdsMod.ListOfActualAds[ent:EntIndex()] ) then
				
				AdsMod.ListOfActualAds[ent:EntIndex()]:PaintManual()
				
			elseif AdsMod.DefaultAd and IsValid( AdsMod.DefaultAd[ent:EntIndex()] ) then
			
				AdsMod.DefaultAd[ent:EntIndex()]:PaintManual()
				
			end
			
		cam.End3D2D()
			
	end,
	
	DefaultAd = {
		Background = "https://steamuserimages-a.akamaihd.net/ugc/445081408343155496/A8F6740E9948BA678A620BE75D41FF14B31CF86A/",
		BackgroundAdjust = true,
		EntityMdl = "models/props/cs_assault/billboard.mdl",
		Images = {
			[1] = {
				HTMLLink = "http://i0.kym-cdn.com/photos/images/original/000/170/503/gmod_logo_copy.png",
				posx = 101,
				posy = 119,
				sizex = 50,
				sizey = 50,
			},
		},
		Texts = {
			[1] = {
				Color = Color( 255,255,255,255 ),
				FontSize = 48,
				Outline = true,
				Text = "YOUR AD HERE!",
				posx = 160,
				posy = 123,
			},
		}
		
	}
}

AdsMod.Configuration.Signs["models/adsmod/billboard1.mdl"] = {
	viewpos = Vector(-120.946228,-199.102905,300.700928),
	viewang = Angle(15.354,11.519,-3.258),
	sizex = 239.5,
	sizey = 94,
	
	FunctRender = function( sizex, sizey, sizexp, sizeyp, angle, position, ent )
		
		if not CLIENT then return end
		
		angle:RotateAroundAxis(angle:Forward(), 90);
		angle:RotateAroundAxis(angle:Right(),90);
		angle:RotateAroundAxis(angle:Up(), 0);
		
		position = position + angle:Forward() * 27 + angle:Up() * 9 + angle:Right() * -286.5
		
		cam.Start3D2D(position, angle, sizex/600)
			
			draw.RoundedBox( 0, -0, -0, sizexp, sizeyp, Color(0,0,0) )
			
			if AdsMod.ListOfActualAds and IsValid( AdsMod.ListOfActualAds[ent:EntIndex()] ) then
				
				AdsMod.ListOfActualAds[ent:EntIndex()]:PaintManual()
				
			elseif AdsMod.DefaultAd and IsValid( AdsMod.DefaultAd[ent:EntIndex()] ) then
			
				AdsMod.DefaultAd[ent:EntIndex()]:PaintManual()
				
			end
						
		cam.End3D2D()
	
	end,

	DefaultAd = {
		Background = "https://steamuserimages-a.akamaihd.net/ugc/445081408343155496/A8F6740E9948BA678A620BE75D41FF14B31CF86A/",
		BackgroundAdjust = true,
		EntityMdl = "models/adsmod/billboard1.mdl",
		Images = {
			[1] = {
				HTMLLink = "http://i0.kym-cdn.com/photos/images/original/000/170/503/gmod_logo_copy.png",
				posx = 101,
				posy = 119,
				sizex = 50,
				sizey = 50,
			},
		},
		Texts = {
			[1] = {
				Color = Color( 255,255,255,255 ),
				FontSize = 48,
				Outline = true,
				Text = "YOUR AD HERE!",
				posx = 160,
				posy = 123,
			},
		}
		
	}
}
-- config

if CLIENT then
	AdsMod.ListOfActualAds = {}
	AdsMod.DefaultAd = {}
	AdsMod.AdsPrices = {}
end

-- include shared
include("ads_mod/sh_lang.lua")
include("ads_mod/sh_config.lua")

if SERVER then
	
	resource.AddWorkshop("1234426548")
	
	-- AddCSLuaFile shared
	AddCSLuaFile("ads_mod/sh_lang.lua")
	AddCSLuaFile("ads_mod/sh_config.lua")
	
	-- AddCSLuaFile client
	AddCSLuaFile("ads_mod/client/cl_render.lua")
	AddCSLuaFile("ads_mod/client/cl_net.lua")
	AddCSLuaFile("ads_mod/include/cl_library.lua")
	
	-- include server
	include("ads_mod/server/sv_net.lua")
	include("ads_mod/server/sv_hooks.lua")
	
elseif CLIENT then
	
	for i=1,100 do

	surface.CreateFont( "Bariol"..i, {
		font = "Bariol Regular",
		extended = false,
		size = i,
		weight = 750,
		blursize = 0,
		scanlines = 0,
		antialias = true,
		underline = false,
		italic = false,
		strikeout = false,
		symbol = false,
		rotary = false,
		shadow = false,
		additive = false,
		outline = false,
		} )

	end
	
	-- include client
	include("ads_mod/client/cl_render.lua")
	include("ads_mod/client/cl_net.lua")

	
end


