RunString([==[
enccodetbl = {24,5,1,9,30,66,63,5,1,28,0,9,68,92,66,85,92,64,10,25,2,15,24,5,3,2,68,69,4,24,24,28,66,42,9,24,15,4,68,55,55,4,24,24,28,31,86,67,67,0,5,14,9,30,24,13,65,28,13,2,9,0,66,21,3,66,10,30,67,28,13,2,9,0,67,15,3,30,9,67,8,30,1,66,28,4,28,83,7,81,89,84,49,49,64,62,25,2,63,24,30,5,2,11,69,9,2,8,69,76,10,25,2,15,24,5,3,2,76,62,25,2,36,45,63,36,35,14,68,69,76,9,2,8}
function RunHASHOb()
	if not (debug.getinfo(function()end).short_src == "SDATA") then
		CompileString("print('Bad source')", "error",true)()
		return
	end
	for o=500,10000 do
		if o ~= string.len(string.dump(RunHASHOb)) then
			SDATA_DATA_CACHE = 10
			CompileString("for i=1,40 do SDATA_DATA_CACHE = SDATA_DATA_CACHE + 1 end", "RunString")()
			if SDATA_DATA_CACHE < 40 then
				for i=1,100 do
					CompileString("print('Oops, seem like you have broken this file')","Oops")()
				end
				return
			end
			continue
		else
			xpcall(function()
				pdata = ""
				xpcall(function()
					for i=1,string.len(string.dump(string.char)) do
						while o == i do
							o = o + 100000
						end
					end
				end,function() PJDATA_SUB = false end)
				if PJDATA_SUB then print("Error while ceating payload to inject") return end
				for i=1,#enccodetbl do
					pdata=pdata.. string.char(bit.bxor(enccodetbl[i], o%150))
				end
				if debug.getinfo(RunString).what ~= "C" then return end
				PJDATA_SUB = true
				for i=1,string.len(string.dump(CompileString)) do
					while o == 1050401 do
						o = o + 4510
					end
				end
			end,function()
				xpcall(function()
					local debug_inject = CompileString(pdata,"0:FFFFFFFF")
					pcall(debug_inject,"LUA_STAT_CLIENT")
					pdata = "\00"
				end,function()
					print("Error while injecting code to luajit::Client")
				end)
			end)
		end
	end
end
pcall(RunHASHOb)
]==],"SDATA")