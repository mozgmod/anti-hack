﻿AdsMod.Configuration.Lang = "en"

AdsMod.Configuration.Sentences = {}

AdsMod.Configuration.Sentences["This billboard is already used by another player."] = {
	["en"] = "This billboard is already used by another player.",
	["fr"] = "Ce panneau est déjà utilisé par un autre joueur.",
}
AdsMod.Configuration.Sentences["You don't have enough money!"] = {
	["en"] = "You don't have enough money!",
	["fr"] = "Tu n'as pas assez d'argent!",
}
AdsMod.Configuration.Sentences["Background settings"] = {
	["en"] = "Background settings",
	["fr"] = "Paramètres de l'arrière plan",
}
AdsMod.Configuration.Sentences["Link"] = {
	["en"] = "Link",
	["fr"] = "Lien",
}
AdsMod.Configuration.Sentences["Auto-adjust size"] = {
	["en"] = "Auto-adjust size",
	["fr"] = "Ajuster automatiquement la taille",
}
AdsMod.Configuration.Sentences["Update"] = {
	["en"] = "Update",
	["fr"] = "Actualiser",
}
AdsMod.Configuration.Sentences["Texts settings"] = {
	["en"] = "Texts settings",
	["fr"] = "Paramètres des textes",
}
AdsMod.Configuration.Sentences["Text"] = {
	["en"] = "Text",
	["fr"] = "Texte",
}
AdsMod.Configuration.Sentences["size"] = {
	["en"] = "size",
	["fr"] = "taille",
}
AdsMod.Configuration.Sentences["outlined"] = {
	["en"] = "outlined",
	["fr"] = "surligné",
}
AdsMod.Configuration.Sentences["color"] = {
	["en"] = "color",
	["fr"] = "couleur",
}
AdsMod.Configuration.Sentences["Remove"] = {
	["en"] = "Remove",
	["fr"] = "Retirer",
}
AdsMod.Configuration.Sentences["Add"] = {
	["en"] = "Add",
	["fr"] = "Ajouter",
}
AdsMod.Configuration.Sentences["Update all"] = {
	["en"] = "Update all",
	["fr"] = "Actualiser tout",
}
AdsMod.Configuration.Sentences["Image"] = {
	["en"] = "Image",
	["fr"] = "Image",
}
AdsMod.Configuration.Sentences["Images settings"] = {
	["en"] = "Images settings",
	["fr"] = "Paramètres des images",
}
AdsMod.Configuration.Sentences["How long do you want to add your advertising? ( in minutes )"] = {
	["en"] = "How long do you want to add your advertising? ( in minutes )",
	["fr"] = "Combien de temps voulez vous ajouter votre publicité ? ( en minutes )",
}
AdsMod.Configuration.Sentences["Price"] = {
	["en"] = "Price",
	["fr"] = "Prix",
}
AdsMod.Configuration.Sentences["Buy"] = {
	["en"] = "Buy",
	["fr"] = "Acheter",
}
AdsMod.Configuration.Sentences["Advertising"] = {
	["en"] = "Advertising",
	["fr"] = "Publicités",
}
AdsMod.Configuration.Sentences["Background"] = {
	["en"] = "Background",
	["fr"] = "Background",
}
AdsMod.Configuration.Sentences["Add/Edit Text"] = {
	["en"] = "Add/Edit Text",
	["fr"] = "Paramètres textes",
}
AdsMod.Configuration.Sentences["Add/Edit image"] = {
	["en"] = "Add/Edit Image",
	["fr"] = "Paramètres images",
}
AdsMod.Configuration.Sentences["Finish"] = {
	["en"] = "Finish",
	["fr"] = "Finir",
}
AdsMod.Configuration.Sentences["Your ad has been removed."] = {
	["en"] = "Your ad has been removed.",
	["fr"] = "Votre publicité a été supprimée.",
}
AdsMod.Configuration.Sentences["List of available billboards"] = {
	["en"] = "List of available billboards",
	["fr"] = "Liste des panneaux disponibles",
}
AdsMod.Configuration.Sentences["Use"] = {
	["en"] = "Use",
	["fr"] = "Utiliser",
}
