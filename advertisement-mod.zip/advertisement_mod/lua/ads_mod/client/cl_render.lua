hook.Add("RenderScene", "RenderScene.AdsMod", function( origin, ang, fov )
	
	if not istable(AdsMod.infosAdsView) then return end
	
	local ent = AdsMod.infosAdsView.ent
	local starttime = AdsMod.infosAdsView.starttime
	
	local pos = ent:GetPos()
	local angle = ent:GetAngles()
			
	local config = AdsMod.Configuration.Signs[ent:GetModel()] or { viewpos = pos, viewang = ang }

	render.RenderView( {
		origin = LerpVector( math.Clamp(CurTime()-starttime,0,1), LocalPlayer():EyePos(), ent:LocalToWorld(config.viewpos) ),
		angles = LerpAngle( math.Clamp(CurTime()-starttime,0,1), LocalPlayer():GetAngles(),ent:LocalToWorldAngles(config.viewang)),
		drawviewmodel = false,
	} )
	
	return true
	
end)

local SignsList = SignsList or {}
-- add all signs in the table
hook.Add("OnEntityCreated", "OnEntityCreated.AdsMod", function( ent )
	if ( ent:GetClass() == "adsmod_sign" ) then
		SignsList[ent:EntIndex()] = ent
	end
end)

hook.Add("PostDrawTranslucentRenderables", "PostDrawTranslucentRenderables.AdsMod", function()
	
	for index, ent in pairs( SignsList ) do

		if not ent or not IsValid( ent ) then SignsList[index] = nil continue end -- remove from the table if not valid
		
		if ent:GetPos():Distance( LocalPlayer():GetPos() ) >= 3000 then continue end
		
		local model = ent:GetModel() 

		if not model then continue end
		
		local sizex = AdsMod.Configuration.Signs[model].sizex
		local sizey = AdsMod.Configuration.Signs[model].sizey
		
		local sizexp = sizex*600/sizex
		local sizeyp = sizey*600/sizex
		
		local angle = ent.Entity:GetAngles()	
		
		local position = ent.Entity:GetPos()
		
		AdsMod.Configuration.Signs[model].FunctRender( sizex, sizey, sizexp, sizeyp, angle, position, ent )
		
	end

end)