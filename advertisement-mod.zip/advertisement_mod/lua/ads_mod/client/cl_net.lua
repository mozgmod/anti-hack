local venalib = include( "ads_mod/include/cl_library.lua" )

net.Receive("AdsMod.Net.OpenGUI", function()
	
	local ent = net.ReadEntity()
	
	if not IsValid( ent ) or ent:GetClass() != "adsmod_sign" then return end
	
	ent:OpenGUI()
	
end)

net.Receive("AdsMod.Net.NPCMenu", function()

	local ent = net.ReadEntity()
	local list = net.ReadTable()
	
	if not IsValid( ent ) then return end
	
	local sizex = 400
	local sizey = 200
	local MainFrame, Frame = venalib.Frame( AdsMod.Configuration.Sentences["List of available billboards"][AdsMod.Configuration.Lang],sizex,sizey )

	local panelM1 = venalib.Panel( sizex-200, sizey-40, 200, 0, MainFrame )
	local panelM2 = venalib.Panel( sizex-200, sizey-40, 0, 0, MainFrame )
	
	local panelM1Title = venalib.Label( "Name : ", 15, sizex-160, 20, 20, 20 , Color(255,255,255), panelM2 )
	panelM1Title:SetWrap(false)	
	
	local panelM2Title = venalib.Label( "Price :", 15, sizex-160, 20, 20, 50 , Color(255,255,255), panelM2 )
	panelM2Title:SetWrap(false)	
	
	MainFrame.Paint = function( pnl, w, h )
		draw.RoundedBox( 0, 0, 0, w,h, Color(36, 36, 44))
	end
	
	local nb = 0

	local butt
	
	for k, v in pairs( list ) do

		local button = venalib.Button( v.name,200, 40, 0, 40*nb, function()
			panelM1Title:SetText( "Name : "..v.name )
			panelM2Title:SetText( "Price : "..v.price.." (/min)" )
			
			if not butt or not IsValid( butt ) then
			
				butt = venalib.Button( AdsMod.Configuration.Sentences["Use"][AdsMod.Configuration.Lang],100, 40, 50-20, 100, function()
					
					if not butt.Index then return end
					
					net.Start("AdsMod.Net.NPCRequest")
						net.WriteInt( butt.Index, 32 )
					net.SendToServer()
					
					Frame:Close()
					
				end, panelM2)
				
				butt.Index = k
				
			else
				butt.Index = k
			end
		end, panelM1 )
		button.Name = v.name
		button.Price = v.price
		
		nb = nb + 1
		
	end
	
end)

net.Receive("AdsMod.Net.BroadcastData", function()
	local data = net.ReadTable()
	local entityIndex = net.ReadUInt( 16 )
	
	if table.Count( data ) == 0 then 
		if AdsMod.ListOfActualAds and IsValid( AdsMod.ListOfActualAds[entityIndex] ) then AdsMod.ListOfActualAds[entityIndex]:Remove() end
		return
	end
	
	local background = data.Background
	local adjust = data.BackgroundAdjust
	local entityMdl = data.EntityMdl
	
	
	if AdsMod.ListOfActualAds and IsValid( AdsMod.ListOfActualAds[entityIndex] ) then AdsMod.ListOfActualAds[entityIndex]:Remove() end
	
	local config = AdsMod.Configuration.Signs[entityMdl]
	
	if not config then return end
	
	local backsizex = config.sizex*600/config.sizex
	local backsizey = config.sizey*600/config.sizex
	
	local frame = vgui.Create("Panel")
	frame:SetPos(0,0)
	frame:SetSize( backsizex, backsizey )
	frame:SetPaintedManually( true )
	
	local toadd = ""
	
	if adjust then
		toadd = "background-size: 100% 100%;"
	end
	
	local dhtml = vgui.Create("HTML", frame )
	dhtml:SetPos( 0,0 )
	dhtml:SetSize( frame:GetSize() )
	dhtml:SetHTML( [[
	
    <html><head><style>body{
        background-attachment: fixed;
        background-image: url("]]..background..[[");
        background-repeat: repeat;
       ]]..toadd..[[
        overflow: hidden;
    }</style></head><body></body></html>
	
	]] 	)
	
	local txts = data.Texts
	
	for k, v in pairs ( txts ) do
		
		local color = v.Color or Color(255,255,255)
		local text = v.Text or ""
		local FontSizer = v.FontSize or 17
		local FontSize = math.Round(FontSizer)
		local outline = v.Outline or false
		local posx = v.posx or 0
		local posy = v.posy or 0
		
		surface.SetFont( "Bariol"..FontSize )
		surface.SetTextColor( color )
		surface.SetTextPos( 0, 0 )
		local sizex, sizey = surface.GetTextSize( text )
		
		local buttonText = vgui.Create( "DButton", dhtml )
		buttonText:SetText( "" )
		buttonText:SetPos( posx, posy )
		buttonText:SetSize( sizex, sizey )
		
		function buttonText:Paint(w,h)
			if outline then
				local outlinewidth = 2

				local steps = ( outlinewidth * 2 ) / 3
				if ( steps < 1 ) then steps = 1 end

				for _x = -outlinewidth, outlinewidth, steps do
					for _y = -outlinewidth, outlinewidth, steps do
						draw.SimpleText( text, "Bariol"..FontSize, 0 + _x, 0 + _y, Color(0,0,0))
					end
				end
			end
			
			surface.SetFont( "Bariol"..FontSize )
			surface.SetTextColor( color )
			surface.SetTextPos( 0, 0 )
			surface.DrawText( text )
		end
		
	end	

	local img = data.Images
	
	for k, v in pairs ( img ) do
		
		local img = v.HTMLLink or ""
		local posx = v.posx or 0
		local posy = v.posy or 0
		local sizex = v.sizex or 0
		local sizey = v.sizey or 0
		
		local html = vgui.Create("HTML", dhtml )
		html:SetPos( posx,posy )
		html:SetSize( sizex,sizey )

		html.HTMLLink = img

		html:SetHTML( [[
		
		<html><head><style>body{
			background-attachment: fixed;
			background-image: url("]]..html.HTMLLink..[[");
			background-repeat: repeat;
			background-size: 100% 100%;
			overflow: hidden;
		}</style></head><body></body></html>
		
		]] 	)
		
	end
	
	AdsMod.ListOfActualAds[entityIndex] = frame

end)


net.Receive("AdsMod.Net.BroadcastConfig", function()
	
	local data = net.ReadTable()
	local price = net.ReadInt( 32 ) or 0
	
	local background = data.Background
	local adjust = data.BackgroundAdjust
	local entityMdl = data.EntityMdl
	local entityIndex = net.ReadUInt( 16 )
	
	AdsMod.AdsPrices[ entityIndex ] = price

	if AdsMod.DefaultAd and IsValid( AdsMod.DefaultAd[entityIndex] ) then AdsMod.DefaultAd[entityIndex]:Remove() end

	local config = AdsMod.Configuration.Signs[entityMdl]
	
	local backsizex = config.sizex*600/config.sizex
	local backsizey = config.sizey*600/config.sizex
	
	local frame = vgui.Create("Panel")
	frame:SetPos(0,0)
	frame:SetSize( backsizex, backsizey )
	frame:SetPaintedManually( true )
	
	local toadd = ""
	
	if adjust then
		toadd = "background-size: 100% 100%;"
	end
	
	local dhtml = vgui.Create("HTML", frame )
	dhtml:SetPos( 0,0 )
	dhtml:SetSize( frame:GetSize() )
	dhtml:SetHTML( [[
	
    <html><head><style>body{
        background-attachment: fixed;
        background-image: url("]]..background..[[");
        background-repeat: repeat;
       ]]..toadd..[[
        overflow: hidden;
    }</style></head><body></body></html>
	
	]] 	)
	
	local txts = data.Texts
	
	for k, v in pairs ( txts ) do
		
		local color = v.Color or Color(255,255,255)
		local text = v.Text or ""
		local FontSizer = v.FontSize or 17
		local FontSize = math.Round(FontSizer)
		local outline = v.Outline or false
		local posx = v.posx or 0
		local posy = v.posy or 0
		
		surface.SetFont( "Bariol"..FontSize )
		surface.SetTextColor( color )
		surface.SetTextPos( 0, 0 )
		local sizex, sizey = surface.GetTextSize( text )
		
		local buttonText = vgui.Create( "DButton", dhtml )
		buttonText:SetText( "" )
		buttonText:SetPos( posx, posy )
		buttonText:SetSize( sizex, sizey )
		
		function buttonText:Paint(w,h)
			if outline then
				local outlinewidth = 2

				local steps = ( outlinewidth * 2 ) / 3
				if ( steps < 1 ) then steps = 1 end

				for _x = -outlinewidth, outlinewidth, steps do
					for _y = -outlinewidth, outlinewidth, steps do
						draw.SimpleText( text, "Bariol"..FontSize, 0 + _x, 0 + _y, Color(0,0,0))
					end
				end
			end
			
			surface.SetFont( "Bariol"..FontSize )
			surface.SetTextColor( color )
			surface.SetTextPos( 0, 0 )
			surface.DrawText( text )
		end
		
	end	

	local img = data.Images
	
	for k, v in pairs ( img ) do
		
		local img = v.HTMLLink or ""
		local posx = v.posx or 0
		local posy = v.posy or 0
		local sizex = v.sizex or 0
		local sizey = v.sizey or 0
		
		local html = vgui.Create("HTML", dhtml )
		html:SetPos( posx,posy )
		html:SetSize( sizex,sizey )

		html.HTMLLink = img

		html:SetHTML( [[
		
		<html><head><style>body{
			background-attachment: fixed;
			background-image: url("]]..html.HTMLLink..[[");
			background-repeat: repeat;
			background-size: 100% 100%;
			overflow: hidden;
		}</style></head><body></body></html>
		
		]] 	)
		
	end
	AdsMod.DefaultAd[entityIndex] = frame
	
end)