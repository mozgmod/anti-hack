local venalib = {}

local matCloseButton = Material( "materials/venatuss/lib/close_button.png" )
local matSwitchOn = Material( "materials/venatuss/lib/switch-on-icon.png" )
local matSwitchOff = Material( "materials/venatuss/lib/switch-off-icon.png" )

venalib.Frame = function( name, sizex, sizey, posx, posy, parent, ent )
	
	local parent = parent or nil
	local sizex = sizex or 500
	local sizey = sizey or 500
	local name = name or ""
	local func = func or function() end
	
	local frame = vgui.Create("DFrame", parent)
	frame:SetSize( sizex, sizey )
	frame:MakePopup()
	frame:ShowCloseButton(false)
	frame:SetTitle("")
	
	if not posx or not posy then
		frame:Center()
	else
		frame:SetPos( posx, posy )
	end
	
	frame.Paint = function( pnl, w, h )
	
		draw.RoundedBox( 3, 0, 0, w,h, Color( 46, 46, 54))
		draw.RoundedBox( 3, 0, 0, w,40, Color( 36, 36, 44))
		draw.RoundedBox( 0, 0, 40, w,2, Color( 26, 26, 34))
		draw.SimpleText( name, "Bariol20", 10, 10, Color( 255, 255, 255, 255 ) )
		
	end
		
	local DermaButton = vgui.Create( "DButton", frame )
	DermaButton:SetText( "" )
	DermaButton:SetPos( sizex-30, 15/2 )
	DermaButton:SetSize( 25, 25 )
	DermaButton.DoClick = function()
		AdsMod.infosAdsView = false
		if frame then frame:Remove() end
		if frame.Linked then
			frame.Linked:Remove()
		end
	end
	DermaButton.Paint = function( pnl, w, h )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( matCloseButton )
		surface.DrawTexturedRect( 0, 0, 25, 25 )
	end
	
	local dpanel = vgui.Create("DPanel", frame)
	dpanel:SetPos( 0, 42 )
	dpanel:SetSize( sizex, sizey-42 )
	dpanel.Paint = function( pnl, w, h )
	end
	
	return dpanel, frame
	
end

venalib.Panel = function( sizex, sizey, posx, posy, parent )
	
	local parent = parent or nil
	local sizex = sizex or 500
	local sizey = sizey or 500
	local type = type or "DScrollPanel"

	local panel = vgui.Create("DScrollPanel", parent)
	panel:SetSize( sizex, sizey )
	
	if not posx or not posy then
		panel:SetPos(0,0)
	else
		panel:SetPos( posx, posy )
	end
	
	panel.Paint = function( pnl, w, h )
		draw.RoundedBox( 0, 0, 0, w,h, Color(46, 46, 54))
	end
	
	local sbar = panel:GetVBar()
	
	function sbar:Paint( w, h )
		draw.RoundedBox( 3, 0, 0, w, h, Color(56, 56, 64) )
	end
	
	function sbar.btnUp:Paint( w, h )
		draw.RoundedBox( 3, 1, 1, w-2, h-2, Color(36, 36, 44) )
	end
	
	function sbar.btnDown:Paint( w, h )
		draw.RoundedBox( 3, 1, 1, w-2, h-2, Color(36, 36, 44) )
	end
	
	function sbar.btnGrip:Paint( w, h )
		draw.RoundedBox( 3, 1, 1, w-3, h-3, Color(36, 36, 44) )
	end
	
	return panel
	
end

venalib.Label = function( text, font, sx, sy, posx, posy, color, Parent, time) 
	
	Parent = Parent or ""
	font = font or 15
	text = text or ""
	sx = sx or 100
	sy = sy or 100
	posx = posx or 0
	posy = posy or 0
	color = color or Color(255,255,255,255)
	time = time or 0

	local EndTime = CurTime() + time
	local SizeString = string.len( text )
	
	local Label = vgui.Create("DLabel", Parent)
		Label:SetPos( posx, posy )
		Label:SetSize( sx,sy )
		if time == 0 then
			Label:SetText( text )
		else
			Label:SetText( "" )
		end
		Label:SetWrap( true )
		Label:SetTextColor(color)
		Label:SetFont("Bariol"..font)
		
	return Label
	
end

local pcall = pcall
local surface_PlaySound = surface.PlaySound
venalib.Button = function( text, sizex, sizey, posx, posy, func, parent )
	
	local text = text or ""
	local sizex = sizex or 100
	local sizey = sizey or 30
	local posx = posx or 0
	local posy = posy or 0
	local parent = parent or nil
	local func = func or function() end
	
	local button = vgui.Create( "DButton", parent )
	button:SetText( "" )
	button:SetPos( posx, posy)
	button:SetSize( sizex, sizey )
	
	local colorr = 36
	local colorg = 36
	local colorb = 44
	
    function button:DoClick()
        local s,e = pcall( func )
        surface_PlaySound( "UI/buttonclick.wav" )
        if not s then
            error( e.." - venalib.Button():DoClick() " )
        end
    end
	
	button.Paint = function( pnl, w, h )
		
		local color = Color( 36, 36, 44)
		local pa = 0.1
		
		if button:IsHovered() then
			colorr = math.Clamp( colorr + pa, 36, 36+5 ) 
			colorg = math.Clamp( colorg + pa, 36, 36+5 ) 
			colorb = math.Clamp( colorb + pa, 44, 44+5 ) 
			color = Color( colorr, colorg, colorb, 255 )
		else
			colorr = math.Clamp( colorr - pa, 36, 36+5 ) 
			colorg = math.Clamp( colorg - pa, 36, 36+5 ) 
			colorb = math.Clamp( colorb - pa, 44, 44+5 ) 
			color = Color( colorr, colorg, colorb, 255 )
		end
		draw.RoundedBox( 0, 0, 0, w,h-2, color)
		draw.RoundedBox( 0, 0, h-2, w,2, Color( 26, 26, 34))
		-- draw.RoundedBox( 0, w-2, 0, 2,h, Color( 31, 31, 41))
		draw.SimpleText( text, "Bariol17", 15, sizey/2-17/2-2, Color( 255, 255, 255, 255 ) )
		draw.SimpleText( "+", "Bariol17", sizex-20, 10, Color( 255, 255, 255, 255 ) )
	end
	function button:OnCursorEntered()
		surface.PlaySound( "UI/buttonrollover.wav" )
	end
	return button
end

return venalib
