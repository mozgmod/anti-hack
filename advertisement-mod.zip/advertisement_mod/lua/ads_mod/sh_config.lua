-- Default settings
AdsMod.Configuration.BaseText = "BASE TEXT"
AdsMod.Configuration.BaseImg = "http://i0.kym-cdn.com/photos/images/original/000/170/503/gmod_logo_copy.png"
AdsMod.Configuration.BaseBackground = "https://steamuserimages-a.akamaihd.net/ugc/445081408343155496/A8F6740E9948BA678A620BE75D41FF14B31CF86A/"

-- Chat commands to save/remove entities
AdsMod.Configuration.SaveEntitiesCMD = "!save_adsmod"
AdsMod.Configuration.RemoveEntitiesCMD = "!remove_adsmod"

-- Maximum advertisement time in minutes
AdsMod.Configuration.TimeMax = 60

AdsMod.Configuration.MoneyUnit = "$"

-- Should they be able to press E on the billboard to edit it or not. False = they can, true = they can't.
AdsMod.Configuration.CanEditBillboardsOnlyOnNPC = false

-- Keep the ad when the player is disconnected. false = remove on DC - true = keep on DC.
AdsMod.Configuration.KeepAdDisconnected = false

-- All usergroups able to edit signs and use admin tools + chat commands.
AdsMod.Configuration.AdminGroups = {
	"admin",
	"owner",
	"founder",
	"superadmin",
}
-- Usergroups who can only use the info tool
AdsMod.Configuration.ModGroups = {
	"moderator",
}

-- Configuration for the advertising NPC
AdsMod.Configuration.AdvertNPCModel = "models/humans/group01/male_02.mdl"

-- Forbidden words, if a link or a text contain one of these words, it will not be added to the billboard
AdsMod.Configuration.ForbiddenStrings = {
	"porn",
	"sex",
    "anal",
    "anus",
    "arse",
    "ass",
    "adderall",
    "ballsack",
    "balls",
    "bastard",
    "bitch",
    "biatch",
    "blowjob",
    "bollock",
    "bollok",
    "boner",
    "boob",
    "bugger",
    "bum",
    "butt",
    "buttplug",
    "clitoris",
    "cock",
    "coon",
    "cocaine",
    "crap",
    "cunt",
    "cum",
    "dick",
    "dildo",
    "ddos",
    "fag",
    "fellate",
    "fellatio",
    "felching",
    "fuck",
    "fudgepacker",
    "homo",
    "jizz",
    "knobend",
    "knob",
    "labia",
    "muff",
    "nigger",
    "nigga",
    "penis",
    "piss",
    "poop",
    "porn",
    "pornhub",
    "prick",
    "pube",
    "pussy",
    "queer",
    "scrotum",
    "stoner",
    "sex",
    "slut",
    "smegma",
    "tit",
    "tosser",
    "turd",
    "twat",
    "vagina",
    "wank",
    "whore",
    "wtf",
}