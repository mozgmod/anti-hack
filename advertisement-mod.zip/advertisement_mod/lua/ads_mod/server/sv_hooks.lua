local function CanEditAdsMod( ply )
	if table.HasValue(AdsMod.Configuration.AdminGroups, ply:GetUserGroup() ) then

		return true
		
	else

		return false
	
	end
end

hook.Add("PlayerDisconnected", "PlayerDisconnected.AdsMod", function( ply )
	if AdsMod.Configuration.KeepAdDisconnected then return end
	
	for k, ent in pairs( ents.FindByClass("adsmod_sign") ) do 
		
		if not ent.AdOwner or ent.AdOwner != ply then continue end
		
		if timer.Exists( "TimerAds"..ent:EntIndex() ) then
			timer.Destroy( "TimerAds"..ent:EntIndex() )
		end
		
		AdsMod.SavedAds[ent] = {}
		
		ent.AdOwner = nil
		
		net.Start("AdsMod.Net.BroadcastData")
			net.WriteTable( AdsMod.SavedAds[ent] )
			net.WriteEntity( ent )
		net.Broadcast()
		
	end
end)

-- Save entities
local AdsModSavedEntities = {
    ["adsmod_sign"] = true,
    ["adsmod_npc"] = true,
}

local configtable = AdsMod.Configuration

local function InitializeTableSavedEnts()
	if not file.Exists("adsmod/"..game.GetMap()..".txt", "DATA") then configtable.SavedEnts = {} return end
   
    local filecontent = file.Read("adsmod/"..game.GetMap()..".txt", "DATA")
   
    configtable.SavedEnts =  util.JSONToTable(filecontent)
end

hook.Add("PlayerSay", "PlayerSay.AdsMod", function( ply, text )
	if not CanEditAdsMod( ply ) then return end
	
	if text != AdsMod.Configuration.SaveEntitiesCMD and text != AdsMod.Configuration.RemoveEntitiesCMD then return end
	
	if text == AdsMod.Configuration.SaveEntitiesCMD then
       
        local savedpos = {}
       
        for k, v in pairs(ents.GetAll()) do
           
            if not AdsModSavedEntities[v:GetClass()] then continue end
			
			local defad = v.DefaultAd or {}
			local price = v.Price or 100
			local usable = v.Usable or false
			local name = v.Name or "Billboard"
			
            savedpos[#savedpos + 1] = {
                pos = v:GetPos(),
                ang = v:GetAngles(),
                class = v:GetClass(),
				price = price,
				defaultad = defad,
				usable = usable,
				model = v:GetModel(),
				name = name,
            }
            file.CreateDir("adsmod")
           
            file.Write("adsmod/"..game.GetMap()..".txt", util.TableToJSON(savedpos))
       
        end
       
	    ply:ChatPrint("[Advertisement Mod] All entities have been sucesfully saved on the map.")
		
		InitializeTableSavedEnts()
		
    end
	
	if text == AdsMod.Configuration.RemoveEntitiesCMD then
	
        if file.Exists("adsmod/"..game.GetMap()..".txt", "DATA") then
		
            file.Delete( "adsmod/"..game.GetMap()..".txt" )
			
            ply:ChatPrint("[Advertisement Mod] All entities have been sucesfully removed from the map.")
			
			InitializeTableSavedEnts()
       
        end
		
    end
end)

-- Init the list of ents to spawn
hook.Add( "Initialize", "Initialize.AdsMod", function()
   InitializeTableSavedEnts()
end )

-- spawn ents
hook.Add("InitPostEntity", "InitPostEntity.AdsMod", function()
    if not configtable.SavedEnts then return end

	timer.Simple(10, function()
		for k, v in pairs(configtable.SavedEnts) do
		
			local ent = ents.Create(v.class)
			ent:SetPos( v.pos )
			ent:SetModel( v.model )
			ent:SetAngles( v.ang )
			ent:SetPersistent( true )
			ent:Spawn()
			local phys = ent:GetPhysicsObject()
	
			if phys:IsValid() then
			
				phys:EnableMotion( false )
				
			end
			
			if v.class != "adsmod_sign" then continue end
					
			timer.Simple( 1, function()
				
				if not IsValid( ent ) then return end
				
				ent.Price = v.price or 100
				ent.DefaultAd = v.defaultad or {}
				ent.Usable = v.usable or false
				ent.Name = v.name or "Billboard"

				net.Start("AdsMod.Net.BroadcastConfig")
					net.WriteTable( ent.DefaultAd )
					net.WriteInt( ent.Price, 32 )
					net.WriteEntity( ent )
				net.Broadcast()
				
			end)
			
		end
	end)
end)

hook.Add("PostCleanupMap", "PostCleanupMap.AdsMod", function()
    if not configtable.SavedEnts then return end
   
    for k, v in pairs(configtable.SavedEnts) do
	
        local ent = ents.Create(v.class)
		ent:SetModel( v.model )
        ent:SetAngles( v.ang )
        ent:SetPersistent( true )
		ent:SetPos( v.pos )
        ent:Spawn()

		local phys = ent:GetPhysicsObject()
	
		if phys:IsValid() then
			
			phys:EnableMotion( false )
		
		end
		
		if v.class != "adsmod_sign" then continue end
		
		timer.Simple( 1, function()
			
			if not IsValid( ent ) then return end
			
			ent.Price = v.price or 100
			ent.DefaultAd = v.defaultad or {}
			ent.Usable = v.usable or false
			ent.Name = v.name or "Billboard"
						
			net.Start("AdsMod.Net.BroadcastConfig")
				net.WriteTable( ent.DefaultAd )
				net.WriteInt( ent.Price, 32 )
				net.WriteEntity( ent )
			net.Broadcast()
			
		end)
    end
end)

-- Send info to the player when joining
hook.Add("PlayerInitialSpawn", "PlayerInitialSpawn.AdsMod", function( ply )
	for key, ent in pairs( ents.FindByClass("adsmod_sign") ) do
		
		if not IsValid( ent ) then continue end
		
		AdsMod.SavedAds[ent] = AdsMod.SavedAds[ent] or {}
				
		net.Start("AdsMod.Net.BroadcastData")
			net.WriteTable( AdsMod.SavedAds[ent] )
			net.WriteEntity( ent )
		net.Broadcast()
	
		net.Start("AdsMod.Net.BroadcastConfig")
			net.WriteTable( ent.DefaultAd or {} )
			net.WriteInt( ent.Price or 0, 32 )
			net.WriteEntity( ent )
		net.Broadcast()
		
	end
end)