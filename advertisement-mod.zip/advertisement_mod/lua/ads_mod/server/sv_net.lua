util.AddNetworkString("AdsMod.Net.OpenGUI")
util.AddNetworkString("AdsMod.Net.AdDataToServer")
util.AddNetworkString("AdsMod.Net.BroadcastData")
util.AddNetworkString("AdsMod.Net.AdDefaultConfig")
util.AddNetworkString("AdsMod.Net.BroadcastConfig")
util.AddNetworkString("AdsMod.Net.NPCMenu")
util.AddNetworkString("AdsMod.Net.NPCRequest")

local spamCooldowns = {}
local interval = .1

local function spamCheck(pl, name)
    if spamCooldowns[pl:SteamID()] then
        if spamCooldowns[pl:SteamID()][name] then
            if spamCooldowns[pl:SteamID()][name] > CurTime() then
                return false
            else
                spamCooldowns[pl:SteamID()][name] = CurTime() + interval
                return true
            end
        else
            spamCooldowns[pl:SteamID()][name] = CurTime() + interval
            return true
        end
    else
        spamCooldowns[pl:SteamID()] = {}
        spamCooldowns[pl:SteamID()][name] = CurTime() + interval

        return true
    end
end

local string_format = string.format
local string_byte = string.byte
local function replacer( character )
	return string_format( "%%%.2X", string_byte( character, 1, 1 ) )
end
local string_gsub = string.gsub
function escapeUrl( url )
	-- http://www.faqs.org/rfcs/rfc1738.html
	return string_gsub( url, "[%z\x01-\x1F\x7F-\xFF<>\"']", replacer )
end

local function CanEditAdsMod( ply )
	
	if table.HasValue(AdsMod.Configuration.AdminGroups, ply:GetUserGroup() ) then

		return true
		
	else

		return false
	
	end
	
end

net.Receive("AdsMod.Net.NPCRequest", function( len, ply )
	
	if not spamCheck( ply, "AdsMod.Net.NPCRequest" ) then return end
	
	local index = net.ReadInt( 32 )
	
	local ent = ents.GetByIndex( index ) or NULL
	
	if not ent or not IsValid(ent) or ent:GetClass() != "adsmod_sign" then return end
	
	ply.ListAdsToSee = {}
	
	ply.ListAdsToSee[index] = ent:GetPos()
	
	net.Start("AdsMod.Net.OpenGUI")
		net.WriteEntity( ent )
	net.Send( ply )
	
end)

net.Receive("AdsMod.Net.AdDataToServer", function( len, ply )
	
	if not spamCheck( ply, "AdsMod.Net.AdDataToServer" ) then return end
	
	local data = net.ReadTable()
	local ent = net.ReadEntity()
	
	-- check if a data is wrong
	if not data.Background or not isstring(data.Background) then return end
	
	if data.Background != escapeUrl( data.Background ) then return end
	
	if not data.EntityMdl or not isstring(data.EntityMdl) then return end

	if not data.Time or not isnumber( data.Time ) or data.Time <= 0 or data.Time > AdsMod.Configuration.TimeMax then return end
	
	if not data.Images then data.Images = {} end
	if not data.Texts then data.Texts = {} end

	local stop = false 

	for k, v in pairs( data.Images ) do
		if not isnumber( k ) then stop = true break end
		if not v.HTMLLink or not isstring( v.HTMLLink ) then stop = true break end
		if not v.posx or not isnumber( v.posx ) then stop = true break end
		if not v.posy or not isnumber( v.posy ) then stop = true break end
		if not v.sizex or not isnumber( v.sizex ) then stop = true break end
		if not v.sizey or not isnumber( v.sizey ) then stop = true break end
		
		local text_s = v.HTMLLink
			
		for key, val in pairs( AdsMod.Configuration.ForbiddenStrings ) do
		
			local text_v = string.find( text_s, val )
				
			if text_v then stop = true break end
			
		end
		
		if text_s != escapeUrl( text_s ) then stop = true end
		
	end
	
	if stop then return end

	
	for k, v in pairs( data.Texts ) do
	
		if not isnumber( k ) then stop = true break end
		if not v.FontSize or not isnumber( v.FontSize ) then stop = true break end
		if not v.Text or not isstring( v.Text ) then stop = true break end
		if not v.posx or not isnumber( v.posx ) then stop = true break end
		if not v.posy or not isnumber( v.posy ) then stop = true break end
		
		local text_s = v.Text
			
		for key, val in pairs( AdsMod.Configuration.ForbiddenStrings ) do
		
			local text_v = string.find( text_s, val )
				
			if text_v then stop = true break end
			
		end
				
	end
	
	if stop then  return end
	--
	
	if not IsValid( ent ) or ent:GetClass() != "adsmod_sign" then return end
	if not ent.Usable then return end
		
	local time = data.Time
	local pricepm = ent.Price or 100
	local price = pricepm * time
	
	if not ply:canAfford( price ) then DarkRP.notify(ply, 1, 10, AdsMod.Configuration.Sentences["You don't have enough money!"][AdsMod.Configuration.Lang] ) return end
	
	if ent.AdOwner and IsValid(ent.AdOwner) then  DarkRP.notify(ply, 1, 10, AdsMod.Configuration.Sentences["This sign is already used by another player."][AdsMod.Configuration.Lang] ) return end
	
	ply:addMoney( -price )
	
	ent.AdOwner = ply
	
	AdsMod.SavedAds[ent] = data
	
	net.Start("AdsMod.Net.BroadcastData")
		net.WriteTable( AdsMod.SavedAds[ent] )
		net.WriteEntity( ent )
	net.Broadcast()
	
	timer.Create("TimerAds"..ent:EntIndex(), 60 * time, 1, function()

		if not ent or not IsValid( ent ) then return end
		
		AdsMod.SavedAds[ent] = {}
		
		if IsValid( ent.AdOwner ) then
			DarkRP.notify(ent.AdOwner, 2, 10, AdsMod.Configuration.Sentences["Your ad has been removed."][AdsMod.Configuration.Lang] )
		end
		
		ent.AdOwner = nil
		
		net.Start("AdsMod.Net.BroadcastData")
			net.WriteTable( AdsMod.SavedAds[ent] )
			net.WriteEntity( ent )
		net.Broadcast()

		
	end)
	
end)

net.Receive("AdsMod.Net.AdDefaultConfig", function( len, ply )
	
	if not spamCheck( ply, "AdsMod.Net.AdDefaultConfig" ) then return end
	
	local data = net.ReadTable()
	local ent = net.ReadEntity()
		
	if not IsValid( ent ) then return end
	
	if not CanEditAdsMod( ply ) then return end
	
	ent.DefaultAd = data
	
	local price = ent.Price or 0
	
	net.Start("AdsMod.Net.BroadcastConfig")
		net.WriteTable( data )
		net.WriteInt( price, 32 )
		net.WriteEntity( ent )
	net.Broadcast()
	
end)

hook.Add("OnEntityCreated", "OnEntityCreated.AdsMod", function( ent )
	
	if not ent:IsPlayer() then return end
	for k, v in pairs( AdsMod.SavedAds ) do
		net.Start("AdsMod.Net.BroadcastData")
			net.WriteTable( v )
			net.WriteEntity( k )
		net.Send( ent )
	end
	
end)